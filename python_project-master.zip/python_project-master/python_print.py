import time 


i=0;

for i in range(0,50):
	time.sleep(1) 
	print i
 
