docker run  -it --rm --name test-python test-python
